﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace paging_316
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] row = new string[] { "Program 1"};
            dataGridView1.Rows.Add(row);
            string[] row2 = new string[] { "Program 2 "};
            dataGridView1.Rows.Add(row2);
            string[] row3 = new string[] { "Program 3"};
            dataGridView1.Rows.Add(row3);
            string[] row4 = new string[] { "Program 4"};
            dataGridView1.Rows.Add(row4);
            string[] row5 = new string[] { "Program 5"};
            dataGridView1.Rows.Add(row5);
        }

        public void dataUpdate()
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string val = textBox1.Text;
            int genNum = rand.Next(1, 5);
           
                string[] row = new string[] { "Program " + val };
                dataGridView3.Rows.Add(row);
            

            /*string[] row2 = new string[] { "Program " +};
            dataGridView1.Rows.Add(row2);

            string[] row3 = new string[] { "Program " };*/
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView3.CurrentCell.RowIndex;
            dataGridView3.Rows.RemoveAt(rowIndex);
            int genNum = rand.Next(1, 5);
           
        }
    } 
}
